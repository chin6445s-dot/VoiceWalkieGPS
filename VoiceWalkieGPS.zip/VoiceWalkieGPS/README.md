# 🎙 VoiceWalkie GPS
### Hands-Free Voice Inspection Notes — Redmi 14C (HyperOS)

---

## 📁 Project Structure

```
VoiceWalkieGPS/
├── build.gradle                         ← Root Gradle config
├── settings.gradle
└── app/
    ├── build.gradle                     ← App dependencies (API 34, Play Services Location)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml          ← All permissions + service declarations
        ├── java/com/voicewalkie/gps/
        │   ├── Constants.kt             ← Shared constants (actions, extras, timing)
        │   ├── MainActivity.kt          ← Setup / Status UI
        │   ├── WalkieService.kt         ← Core foreground service (STT + GPS + File)
        │   └── VolumeKeyAccessibilityService.kt  ← Volume key interceptor
        └── res/
            ├── layout/activity_main.xml
            ├── values/{strings, colors, themes}.xml
            ├── xml/accessibility_service_config.xml
            └── drawable/ic_launcher_foreground.xml
```

---

## ⚙️ Architecture Overview

```
[Volume UP Button]
        │
        ▼
[VolumeKeyAccessibilityService]  ← Works with screen OFF
   Single press (< 500ms gap)
        │  sendIntent → ACTION_START_RECORDING
        ▼
[WalkieService]  (Foreground, STICKY)
   ① BEEP + vibrate
   ② SpeechRecognizer.startListening()
        │
   Double press → ACTION_STOP_RECORDING
        │
   ① BEEP-BEEP + double vibrate
   ② SpeechRecognizer.stopListening()
   ③ onResults callback fires
   ④ FusedLocationProviderClient.getCurrentLocation()
   ⑤ Format + Append to /Documents/TourNotes.txt
   ⑥ Broadcast → MainActivity updates UI
```

---

## 📱 First-Time Setup (in order)

### Step 1 — Build & Install
```bash
cd VoiceWalkieGPS
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Step 2 — Grant Permissions
Open the app → tap **"Grant Required Permissions"**

Permissions requested:
| Permission | Purpose |
|---|---|
| `RECORD_AUDIO` | Speech recognition |
| `ACCESS_FINE_LOCATION` | GPS tagging |
| `POST_NOTIFICATIONS` | Foreground service notification |
| `WRITE_EXTERNAL_STORAGE` | (API ≤ 29 only) File writing |

### Step 3 — Enable Accessibility Service ⚠️ Critical

Tap **"Enable Accessibility Service"** → System Settings opens.

Navigate to:
> Settings → Accessibility → Installed Services → **VoiceWalkie Volume Key Listener** → ON

**HyperOS Note:** You may also need to go to:
> Settings → Apps → VoiceWalkie GPS → Battery → **No Restrictions**
> Settings → Apps → VoiceWalkie GPS → Other Permissions → **Allow running in background**

### Step 4 — Start the Service
Tap **"▶ Start Walkie Service"**

A persistent notification appears: `VoiceWalkie GPS Active`

---

## 🚀 Using on Tour

1. Start the service
2. Lock your screen
3. Put your phone in your pocket

**Controls (screen can be completely OFF):**

| Action | Response |
|---|---|
| **Vol UP × 1** | 🔊 BEEP + short vibration → Recording starts |
| **Vol UP × 2** | 🔊 BEEP-BEEP + double vibration → Stops & saves |

---

## 📄 Output Format

Notes are saved to:
```
/sdcard/Documents/TourNotes.txt
```

Each line:
```
[2026-03-27 14:20:05] [GPS: 17.123456, 101.456789] -> Beautiful fruit stand on the left near the valley entrance.
[2026-03-27 14:25:31] [GPS: 17.124100, 101.458200] -> Road narrows here, check drainage on right side.
```

---

## 🛡 HyperOS Stability Tips

HyperOS (Redmi 14C) is aggressive with background process killing. Apply ALL of these:

1. **Battery Settings** → App → No Restrictions (Auto-start: ON)
2. **Lock the app** in Recents (swipe up, hold the card, tap lock icon)
3. **MIUI Security** → Boost Speed → DO NOT include VoiceWalkie in cleanup
4. The foreground service uses `START_STICKY` — it will restart if killed
5. The Accessibility Service is system-level and survives most kills

---

## 🔧 Customization

### Change Double-Press Window
In `Constants.kt`:
```kotlin
const val DOUBLE_PRESS_WINDOW_MS = 500L  // increase to 700L if too sensitive
```

### Change Beep Tone
In `WalkieService.kt`:
```kotlin
private const val TONE_TYPE_START = ToneGenerator.TONE_PROP_BEEP    // change tone
private const val TONE_TYPE_STOP  = ToneGenerator.TONE_PROP_BEEP2
```

### Change Output File Name / Location
In `Constants.kt`:
```kotlin
const val NOTES_FILENAME = "TourNotes.txt"
```
And in `WalkieService.saveNote()` adjust `Environment.DIRECTORY_DOCUMENTS`.

---

## 🐛 Troubleshooting

| Problem | Solution |
|---|---|
| Volume button not triggering | Check Accessibility Service is enabled & running |
| No GPS in notes | Grant `ACCESS_FINE_LOCATION`, go outside for GPS fix |
| Speech not recognized | Check internet connection (Google STT is online) |
| Service killed by HyperOS | Apply all Battery Settings steps above |
| File not found | Check `/sdcard/Documents/` exists; grant storage permission |
| "Recognizer busy" error | Previous session didn't close; restart the service |

---

## 📋 Requirements

- Android API 26+ (Android 8.0+)
- Google Play Services (for FusedLocationProvider)
- Google app installed (for SpeechRecognizer)
- Internet connection (for online STT)
- Compiled with `compileSdk 34`, `targetSdk 34`
