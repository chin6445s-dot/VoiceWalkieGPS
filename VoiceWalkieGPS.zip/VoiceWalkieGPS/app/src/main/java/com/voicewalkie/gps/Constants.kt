package com.voicewalkie.gps

/**
 * Shared constants used across Activities, Services and AccessibilityService.
 */
object Constants {

    // ── Intent Actions ────────────────────────────────────────────────────
    const val ACTION_START_SERVICE      = "com.voicewalkie.gps.START_SERVICE"
    const val ACTION_STOP_SERVICE       = "com.voicewalkie.gps.STOP_SERVICE"
    const val ACTION_START_RECORDING    = "com.voicewalkie.gps.START_RECORDING"
    const val ACTION_STOP_RECORDING     = "com.voicewalkie.gps.STOP_RECORDING"

    // ── Broadcast Actions (Service → Activity / Accessibility → Service) ──
    const val BROADCAST_NOTE_SAVED      = "com.voicewalkie.gps.NOTE_SAVED"
    const val BROADCAST_RECORDING_STATE = "com.voicewalkie.gps.RECORDING_STATE"

    // ── Broadcast Extras ──────────────────────────────────────────────────
    const val EXTRA_NOTE_TEXT           = "note_text"
    const val EXTRA_IS_RECORDING        = "is_recording"

    // ── Notification ──────────────────────────────────────────────────────
    const val NOTIFICATION_CHANNEL_ID   = "voicewalkie_channel"
    const val NOTIFICATION_ID           = 1001

    // ── Volume Key Timing ─────────────────────────────────────────────────
    /** Max milliseconds between two presses to count as a double-press */
    const val DOUBLE_PRESS_WINDOW_MS    = 500L

    // ── File ──────────────────────────────────────────────────────────────
    const val NOTES_FILENAME            = "TourNotes.txt"
}
