package com.voicewalkie.gps

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Environment
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ══════════════════════════════════════════════════════════════════════
 *  WalkieService  —  Core Foreground Service
 * ══════════════════════════════════════════════════════════════════════
 *
 *  Responsibilities:
 *  1. Runs as a STICKY foreground service (survives HyperOS memory pressure)
 *  2. Responds to ACTION_START_RECORDING / ACTION_STOP_RECORDING intents
 *     sent by VolumeKeyAccessibilityService
 *  3. Audio feedback via ToneGenerator:
 *       Start → single high-pitched BEEP  + short vibration
 *       Stop  → double BEEP-BEEP          + double vibration
 *  4. Runs Google Online SpeechRecognizer
 *  5. On stop: fetches last known location from FusedLocationProviderClient
 *  6. Formats and appends a line to /Documents/TourNotes.txt
 *  7. Broadcasts results to MainActivity for live UI updates
 * ══════════════════════════════════════════════════════════════════════
 */
class WalkieService : Service() {

    companion object {
        private const val TAG = "WalkieService"
        private const val BEEP_DURATION_MS   = 150
        private const val BEEP_GAP_MS        = 130L
        private const val BEEP_VOLUME        = 100  // 0-100
        private const val TONE_TYPE_START    = ToneGenerator.TONE_PROP_BEEP
        private const val TONE_TYPE_STOP     = ToneGenerator.TONE_PROP_BEEP2
    }

    // ── Dependencies ──────────────────────────────────────────────────
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var vibrator: Vibrator
    private lateinit var toneGenerator: ToneGenerator

    // ── State ─────────────────────────────────────────────────────────
    private var isRecording = false
    private var pendingTranscription: String? = null

    // ──────────────────────────────────────────────────────────────────
    //  Lifecycle
    // ──────────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "onCreate")

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        vibrator            = getVibrator()
        toneGenerator       = ToneGenerator(AudioManager.STREAM_MUSIC, BEEP_VOLUME)

        createNotificationChannel()
        startForeground(Constants.NOTIFICATION_ID, buildNotification())
        initSpeechRecognizer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            Constants.ACTION_START_RECORDING -> handleStartRecording()
            Constants.ACTION_STOP_RECORDING  -> handleStopRecording()
            Constants.ACTION_STOP_SERVICE    -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy")
        if (::speechRecognizer.isInitialized) {
            speechRecognizer.destroy()
        }
        toneGenerator.release()
    }

    // ──────────────────────────────────────────────────────────────────
    //  Recording Control
    // ──────────────────────────────────────────────────────────────────

    private fun handleStartRecording() {
        if (isRecording) {
            Log.w(TAG, "Already recording – ignoring start")
            return
        }
        Log.d(TAG, "Starting recording")
        isRecording = true
        pendingTranscription = null

        beepStart()
        broadcastRecordingState(true)
        startListening()
    }

    private fun handleStopRecording() {
        if (!isRecording) {
            Log.w(TAG, "Not recording – ignoring stop")
            return
        }
        Log.d(TAG, "Stopping recording")
        isRecording = false

        beepStop()
        speechRecognizer.stopListening()
        broadcastRecordingState(false)
        // Result is handled asynchronously in onResults / onError
    }

    // ──────────────────────────────────────────────────────────────────
    //  SpeechRecognizer
    // ──────────────────────────────────────────────────────────────────

    private fun initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.e(TAG, "SpeechRecognizer not available on this device")
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {

            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim() ?: ""
                Log.d(TAG, "onResults: $text")
                if (text.isNotEmpty()) {
                    fetchLocationAndSave(text)
                } else {
                    Log.w(TAG, "Empty transcription – nothing saved")
                }
            }

            override fun onError(error: Int) {
                val msg = speechErrorMessage(error)
                Log.e(TAG, "SpeechRecognizer error: $msg ($error)")
                isRecording = false
                broadcastRecordingState(false)
            }

            override fun onPartialResults(partialResults: Bundle) {
                val partial = partialResults
                    .getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: ""
                Log.v(TAG, "Partial: $partial")
            }

            // ── Unused callbacks (required by interface) ───────────
            override fun onReadyForSpeech(params: Bundle)    { Log.v(TAG, "Ready") }
            override fun onBeginningOfSpeech()               { Log.v(TAG, "Speaking") }
            override fun onRmsChanged(rmsdB: Float)          {}
            override fun onBufferReceived(buffer: ByteArray) {}
            override fun onEndOfSpeech()                     { Log.v(TAG, "End of speech") }
            override fun onEvent(eventType: Int, params: Bundle) {}
        })
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                     RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // Allow long pauses (up to 10 s of silence before auto-stop)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 10_000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 5_000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 500L)
        }
        try {
            speechRecognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startListening failed", e)
            isRecording = false
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Location Fetch + File Save
    // ──────────────────────────────────────────────────────────────────

    private fun fetchLocationAndSave(transcription: String) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "Location permission not granted – saving without GPS")
            saveNote(transcription, null, null)
            return
        }

        // Try fresh current location first (high accuracy), fall back to last known
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { location ->
                if (location != null) {
                    saveNote(transcription, location.latitude, location.longitude)
                } else {
                    // Fall back to last known
                    fusedLocationClient.lastLocation.addOnSuccessListener { last ->
                        saveNote(transcription, last?.latitude, last?.longitude)
                    }.addOnFailureListener {
                        saveNote(transcription, null, null)
                    }
                }
            }
            .addOnFailureListener {
                Log.w(TAG, "getCurrentLocation failed, trying lastLocation")
                fusedLocationClient.lastLocation.addOnSuccessListener { last ->
                    saveNote(transcription, last?.latitude, last?.longitude)
                }.addOnFailureListener {
                    saveNote(transcription, null, null)
                }
            }
    }

    private fun saveNote(transcription: String, lat: Double?, lon: Double?) {
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val gps = if (lat != null && lon != null) {
            "GPS: %.6f, %.6f".format(lat, lon)
        } else {
            "GPS: unavailable"
        }
        val line = "[$timestamp] [$gps] -> $transcription\n"

        try {
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, Constants.NOTES_FILENAME)
            file.appendText(line, Charsets.UTF_8)
            Log.d(TAG, "Note saved: $line")
            broadcastNoteSaved(line.trim())
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save note", e)
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Audio Feedback
    // ──────────────────────────────────────────────────────────────────

    /** Single high-pitched beep + short vibration */
    private fun beepStart() {
        toneGenerator.startTone(TONE_TYPE_START, BEEP_DURATION_MS)
        vibratePattern(longArrayOf(0, 80))
    }

    /** Double beep + double vibration */
    private fun beepStop() {
        Thread {
            toneGenerator.startTone(TONE_TYPE_STOP, BEEP_DURATION_MS)
            Thread.sleep(BEEP_DURATION_MS + BEEP_GAP_MS)
            toneGenerator.startTone(TONE_TYPE_STOP, BEEP_DURATION_MS)
        }.start()
        vibratePattern(longArrayOf(0, 80, 100, 80))
    }

    private fun vibratePattern(pattern: LongArray) {
        try {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (e: Exception) {
            Log.w(TAG, "Vibration failed", e)
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Broadcasts to MainActivity
    // ──────────────────────────────────────────────────────────────────

    private fun broadcastRecordingState(isRec: Boolean) {
        sendBroadcast(Intent(Constants.BROADCAST_RECORDING_STATE).apply {
            putExtra(Constants.EXTRA_IS_RECORDING, isRec)
            setPackage(packageName)
        })
    }

    private fun broadcastNoteSaved(noteText: String) {
        sendBroadcast(Intent(Constants.BROADCAST_NOTE_SAVED).apply {
            putExtra(Constants.EXTRA_NOTE_TEXT, noteText)
            setPackage(packageName)
        })
    }

    // ──────────────────────────────────────────────────────────────────
    //  Notification
    // ──────────────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            Constants.NOTIFICATION_CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "VoiceWalkie GPS keeps running during tours"
            setSound(null, null)
        }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, WalkieService::class.java).apply {
                action = Constants.ACTION_STOP_SERVICE
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_delete, "Stop", stopIntent)
            .build()
    }

    // ──────────────────────────────────────────────────────────────────
    //  Utilities
    // ──────────────────────────────────────────────────────────────────

    @Suppress("DEPRECATION")
    private fun getVibrator(): Vibrator {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun speechErrorMessage(code: Int) = when (code) {
        SpeechRecognizer.ERROR_AUDIO                 -> "Audio error"
        SpeechRecognizer.ERROR_CLIENT                -> "Client error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
        SpeechRecognizer.ERROR_NETWORK               -> "Network error"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT       -> "Network timeout"
        SpeechRecognizer.ERROR_NO_MATCH              -> "No speech match"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY       -> "Recognizer busy"
        SpeechRecognizer.ERROR_SERVER                -> "Server error"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT        -> "Speech timeout"
        else                                         -> "Unknown error"
    }
}
