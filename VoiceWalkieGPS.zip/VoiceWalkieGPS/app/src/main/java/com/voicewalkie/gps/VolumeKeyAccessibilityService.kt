package com.voicewalkie.gps

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * ══════════════════════════════════════════════════════════════════════
 *  VolumeKeyAccessibilityService
 * ══════════════════════════════════════════════════════════════════════
 *
 *  Intercepts hardware Volume UP key presses using the Accessibility API.
 *  This works even when the screen is OFF on most Android devices.
 *
 *  Single Press  → Sends ACTION_START_RECORDING to WalkieService
 *  Double Press  → Sends ACTION_STOP_RECORDING  to WalkieService
 *
 *  The double-press is detected via a short timer window (DOUBLE_PRESS_WINDOW_MS).
 *  If a second press arrives within the window, it's a double-press; otherwise
 *  the pending single-press action fires.
 *
 *  Volume DOWN is passed through normally (not consumed).
 * ══════════════════════════════════════════════════════════════════════
 */
class VolumeKeyAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "VolumeKeyService"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastVolUpPressTime = 0L
    private var pendingSinglePress: Runnable? = null

    // ──────────────────────────────────────────────────────────────────
    //  Key Event Interception
    // ──────────────────────────────────────────────────────────────────

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Only act on Volume UP, ACTION_DOWN (ignore UP action to avoid double-fire)
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action != KeyEvent.ACTION_DOWN)         return false

        val now = SystemClock.uptimeMillis()
        val timeSinceLast = now - lastVolUpPressTime
        lastVolUpPressTime = now

        return if (timeSinceLast <= Constants.DOUBLE_PRESS_WINDOW_MS && pendingSinglePress != null) {
            // ── Double Press detected ──────────────────────────────────
            Log.d(TAG, "Double press → STOP RECORDING")
            handler.removeCallbacks(pendingSinglePress!!)
            pendingSinglePress = null
            sendActionToService(Constants.ACTION_STOP_RECORDING)
            true  // consume the key event
        } else {
            // ── Potential Single Press – wait to see if double follows ─
            pendingSinglePress?.let { handler.removeCallbacks(it) }
            pendingSinglePress = Runnable {
                Log.d(TAG, "Single press → START RECORDING")
                sendActionToService(Constants.ACTION_START_RECORDING)
                pendingSinglePress = null
            }
            handler.postDelayed(pendingSinglePress!!, Constants.DOUBLE_PRESS_WINDOW_MS)
            true  // consume the key event
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Helper
    // ──────────────────────────────────────────────────────────────────

    private fun sendActionToService(action: String) {
        val intent = Intent(this, WalkieService::class.java).apply {
            this.action = action
        }
        try {
            startForegroundService(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Could not send action $action to WalkieService", e)
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Required overrides (unused)
    // ──────────────────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent) { /* not used */ }

    override fun onInterrupt() {
        Log.w(TAG, "AccessibilityService interrupted")
        handler.removeCallbacksAndMessages(null)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
