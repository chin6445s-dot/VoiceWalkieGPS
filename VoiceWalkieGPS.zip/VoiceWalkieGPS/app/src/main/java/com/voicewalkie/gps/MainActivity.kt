package com.voicewalkie.gps

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.voicewalkie.gps.databinding.ActivityMainBinding
import java.io.File

/**
 * ══════════════════════════════════════════════════════════════════════
 *  MainActivity  —  Setup & Status Screen
 * ══════════════════════════════════════════════════════════════════════
 *
 *  This is the single "control panel" screen for VoiceWalkie GPS.
 *  It handles:
 *  ① Permission requests (RECORD_AUDIO, ACCESS_FINE_LOCATION,
 *                          POST_NOTIFICATIONS, WRITE_EXTERNAL_STORAGE)
 *  ② Guiding user to enable the AccessibilityService in system settings
 *  ③ Starting / stopping WalkieService
 *  ④ Showing live status updates via BroadcastReceiver
 *  ⑤ Quick-opening the TourNotes.txt file
 * ══════════════════════════════════════════════════════════════════════
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // ── Required permissions ──────────────────────────────────────────
    private val requiredPermissions = mutableListOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }.toTypedArray()

    // ── Permission launcher ───────────────────────────────────────────
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            toast("✅ All permissions granted!")
        } else {
            val denied = results.filterValues { !it }.keys.joinToString("\n")
            toast("❌ Denied:\n$denied\n\nPlease grant manually in App Settings.")
        }
        updateStatusUI()
    }

    // ── Broadcast Receiver ────────────────────────────────────────────
    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Constants.BROADCAST_RECORDING_STATE -> {
                    val isRec = intent.getBooleanExtra(Constants.EXTRA_IS_RECORDING, false)
                    binding.cardRecording.visibility = if (isRec) View.VISIBLE else View.GONE
                }
                Constants.BROADCAST_NOTE_SAVED -> {
                    val note = intent.getStringExtra(Constants.EXTRA_NOTE_TEXT) ?: return
                    binding.cardLastNote.visibility = View.VISIBLE
                    binding.tvLastNote.text = note
                    toast("📝 Note saved!")
                }
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Lifecycle
    // ──────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClickListeners()
        registerReceiver()
    }

    override fun onResume() {
        super.onResume()
        updateStatusUI()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(broadcastReceiver) } catch (_: Exception) {}
    }

    // ──────────────────────────────────────────────────────────────────
    //  Click Listeners
    // ──────────────────────────────────────────────────────────────────

    private fun setupClickListeners() {

        // ── Grant Permissions ──────────────────────────────────────────
        binding.btnGrantPermissions.setOnClickListener {
            if (allPermissionsGranted()) {
                toast("✅ All permissions already granted!")
            } else {
                permissionLauncher.launch(requiredPermissions)
            }
        }

        // ── Enable Accessibility Service ───────────────────────────────
        binding.btnEnableAccessibility.setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                toast("✅ Accessibility service is already enabled!")
            } else {
                toast("Find 'VoiceWalkie Volume Key Listener' and enable it")
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        // ── Start Service ──────────────────────────────────────────────
        binding.btnStartService.setOnClickListener {
            when {
                !allPermissionsGranted() -> {
                    toast("⚠️ Please grant all permissions first")
                    return@setOnClickListener
                }
                !isAccessibilityServiceEnabled() -> {
                    toast("⚠️ Please enable the Accessibility Service first")
                    return@setOnClickListener
                }
                else -> {
                    startWalkieService()
                    toast("🚀 Walkie Service started! You can now lock the screen.")
                }
            }
            updateStatusUI()
        }

        // ── Stop Service ───────────────────────────────────────────────
        binding.btnStopService.setOnClickListener {
            stopWalkieService()
            binding.cardRecording.visibility = View.GONE
            updateStatusUI()
            toast("⏹ Walkie Service stopped")
        }

        // ── Open Notes File ────────────────────────────────────────────
        binding.btnOpenNotes.setOnClickListener {
            openNotesFile()
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Status UI Update
    // ──────────────────────────────────────────────────────────────────

    private fun updateStatusUI() {
        val permOk  = allPermissionsGranted()
        val a11yOk  = isAccessibilityServiceEnabled()

        // Permissions
        binding.tvStatusPermissions.apply {
            if (permOk) {
                text      = getString(R.string.status_permissions_ok)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.colorSuccess))
            } else {
                text      = getString(R.string.status_permissions_missing)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.colorError))
            }
        }

        // Accessibility
        binding.tvStatusAccessibility.apply {
            if (a11yOk) {
                text      = getString(R.string.status_accessibility_ok)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.colorSuccess))
            } else {
                text      = getString(R.string.status_accessibility_missing)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.colorError))
            }
        }

        // Service (heuristic: check notification / just reflect last action)
        // A more robust check would use a shared preference flag set by WalkieService
        binding.tvStatusService.apply {
            val running = isWalkieServiceRunning()
            if (running) {
                text      = getString(R.string.status_service_running)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.colorSuccess))
            } else {
                text      = getString(R.string.status_service_stopped)
                setTextColor(ContextCompat.getColor(this@MainActivity, R.color.colorWarning))
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Service Control
    // ──────────────────────────────────────────────────────────────────

    private fun startWalkieService() {
        val intent = Intent(this, WalkieService::class.java).apply {
            action = Constants.ACTION_START_SERVICE
        }
        ContextCompat.startForegroundService(this, intent)
        getSharedPreferences("prefs", Context.MODE_PRIVATE)
            .edit().putBoolean("service_running", true).apply()
    }

    private fun stopWalkieService() {
        val intent = Intent(this, WalkieService::class.java).apply {
            action = Constants.ACTION_STOP_SERVICE
        }
        startService(intent)
        getSharedPreferences("prefs", Context.MODE_PRIVATE)
            .edit().putBoolean("service_running", false).apply()
    }

    private fun isWalkieServiceRunning(): Boolean {
        return getSharedPreferences("prefs", Context.MODE_PRIVATE)
            .getBoolean("service_running", false)
    }

    // ──────────────────────────────────────────────────────────────────
    //  Open Notes File
    // ──────────────────────────────────────────────────────────────────

    private fun openNotesFile() {
        val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val file = File(dir, Constants.NOTES_FILENAME)

        if (!file.exists()) {
            toast("📄 No notes yet – TourNotes.txt will be created on first save")
            return
        }

        // Use a file manager / text viewer intent
        val uri = Uri.fromFile(file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "text/plain")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("No app found to open .txt files. Path:\n${file.absolutePath}")
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Permission Helpers
    // ──────────────────────────────────────────────────────────────────

    private fun allPermissionsGranted(): Boolean {
        return requiredPermissions.all { perm ->
            ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Accessibility Service Check
    // ──────────────────────────────────────────────────────────────────

    private fun isAccessibilityServiceEnabled(): Boolean {
        val serviceId = "$packageName/${VolumeKeyAccessibilityService::class.java.canonicalName}"
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(serviceId, ignoreCase = true) }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Broadcast Receiver Registration
    // ──────────────────────────────────────────────────────────────────

    private fun registerReceiver() {
        val filter = IntentFilter().apply {
            addAction(Constants.BROADCAST_RECORDING_STATE)
            addAction(Constants.BROADCAST_NOTE_SAVED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(broadcastReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(broadcastReceiver, filter)
        }
    }

    // ──────────────────────────────────────────────────────────────────
    //  Utilities
    // ──────────────────────────────────────────────────────────────────

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
