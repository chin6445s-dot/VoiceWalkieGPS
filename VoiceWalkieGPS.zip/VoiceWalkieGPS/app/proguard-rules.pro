# VoiceWalkie GPS ProGuard Rules

# Keep all classes in our package
-keep class com.voicewalkie.gps.** { *; }

# Keep Google Play Services Location
-keep class com.google.android.gms.location.** { *; }

# Keep Speech Recognizer
-keep class android.speech.** { *; }
